<?php

header("Content-Type: application/json; charset=UTF-8");

require_once "conecta.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Método não permitido."
    ]);

    exit;
}

$dados = json_decode(file_get_contents("php://input"), true);

$id = $dados["id"] ?? 0;
$status = $dados["status"] ?? "";

if (empty($id) || empty($status)) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "ID e status são obrigatórios."
    ]);

    exit;
}

try {

    // Se o status for "Fechado", exclui o registro
    if ($status === "Fechado") {
        $sql = "DELETE FROM ocorrencias WHERE id = :id";

        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":id", $id);

        $stmt->execute();

        echo json_encode([
            "sucesso" => true,
            "mensagem" => "Ocorrência fechada e excluída com sucesso!"
        ]);
    } else {
        // Caso contrário, apenas atualiza o status
        $sql = "UPDATE ocorrencias SET status = :status WHERE id = :id";

        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":status", $status);
        $stmt->bindParam(":id", $id);

        $stmt->execute();

        echo json_encode([
            "sucesso" => true,
            "mensagem" => "Status atualizado com sucesso!"
        ]);
    }

} catch (PDOException $e) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Erro ao processar ocorrência."
    ]);
}
