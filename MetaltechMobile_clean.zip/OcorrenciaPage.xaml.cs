﻿using MetaltechMobile.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MetaltechMobile
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class OcorrenciaPage : ContentPage
    {
        private string operador;
        public OcorrenciaPage(string operador)
        {
            InitializeComponent();
            this.operador = operador;

            txtOperador.Text = operador;
            txtOperador.IsEnabled = true;
        }

        private async void btnRegistrar_Clicked(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaquina.Text))
            {
                await DisplayAlert(
                    "Atenção",
                    "Informe a máquina.",
                    "OK");

                return;
            }

            if (string.IsNullOrWhiteSpace(txtCodigoErro.Text))
            {
                await DisplayAlert(
                    "Atenção",
                    "Informe o código do erro.",
                    "OK");

                return;
            }

            if (string.IsNullOrWhiteSpace(txtErro.Text))
            {
                await DisplayAlert(
                    "Atenção",
                    "Informe a descrição do erro.",
                    "OK");

                return;
            }

            if (string.IsNullOrWhiteSpace(txtOperador.Text))
            {
                await DisplayAlert(
                    "Atenção",
                    "Informe o operador.",
                    "OK");

                return;
            }

            Ocorrencia ocorrencia = new Ocorrencia();

            ocorrencia.Maquina = txtMaquina.Text;
            ocorrencia.CodigoErro = txtCodigoErro.Text;
            ocorrencia.DescricaoErro = txtErro.Text;
            ocorrencia.DataHora = DateTime.Now;
            ocorrencia.Operador = txtOperador.Text;

            try
            {
                using (HttpClient cliente = new HttpClient())
                {
                    string url =
                        "http://10.0.2.2/Metaltech/Metaltech/registrar_ocorrencia.php";

                    var dados = new
                    {
                        usuario = ocorrencia.Operador,
                        perfil = "Operador",
                        maquina = ocorrencia.Maquina,
                        codigo_erro = txtCodigoErro.Text,
                        descricao_erro = ocorrencia.DescricaoErro,
                        data_hora = ocorrencia.DataHora.ToString("yyyy-MM-dd HH:mm:ss"),
                        status = "Aberto"
                    };

                    string json = JsonConvert.SerializeObject(dados);

                    StringContent conteudo = new StringContent(
                        json,
                        Encoding.UTF8,
                        "application/json");

                    HttpResponseMessage resposta =
                        await cliente.PostAsync(url, conteudo);

                    string resultado =
                        await resposta.Content.ReadAsStringAsync();

                    if (!resposta.IsSuccessStatusCode)
                    {
                        await DisplayAlert(
                            "Erro no Servidor",
                            $"Status: {resposta.StatusCode}\n\n{resultado}",
                            "OK");
                        return;
                    }

                    await DisplayAlert(
                        "Sucesso",
                        "Ocorrência registrada com sucesso!",
                        "OK");

                    // Perguntar se deseja inserir outro registro
                    bool outroRegistro = await DisplayAlert(
                        "Novo Registro",
                        "Deseja inserir outro registro?",
                        "Sim",
                        "Não");

                    if (outroRegistro)
                    {
                        // Limpar campos para novo registro
                        txtMaquina.Text = "";
                        txtCodigoErro.Text = "";
                        txtErro.Text = "";
                        txtOperador.Text = operador;
                    }
                    else
                    {
                        // Voltar para o menu
                        await Navigation.PopAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert(
                    "Erro de Conexão",
                    $"Não foi possível conectar ao servidor.\n\nDetalhes: {ex.Message}",
                    "OK");
            }
        }
    }
}