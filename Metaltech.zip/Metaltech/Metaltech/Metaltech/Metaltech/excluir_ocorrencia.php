<?php

header("Content-Type: application/json; charset=UTF-8");

require_once "conecta.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Método não permitido."
    ]);

    exit;
}

$dados = json_decode(file_get_contents("php://input"), true);

$id = $dados["id"] ?? 0;

if (empty($id)) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "ID é obrigatório."
    ]);

    exit;
}

try {

    $sql = "DELETE FROM ocorrencias WHERE id = :id";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":id", $id);

    $stmt->execute();

    echo json_encode([
        "sucesso" => true,
        "mensagem" => "Ocorrência excluída com sucesso!"
    ]);

} catch (PDOException $e) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Erro ao excluir ocorrência."
    ]);
}
