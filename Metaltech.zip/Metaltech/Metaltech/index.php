<?php
session_start();

// Se já estiver logado, redirecionar para o menu
if (isset($_SESSION['usuario']) && isset($_SESSION['perfil'])) {
    header("Location: menu.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - MetalTech</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="login-container">
        <div class="login-box">
            <h1>MetalTech</h1>
            <h2>Sistema de Monitoramento de Erros Industriais</h2>
            <form id="loginForm">
                <div class="form-group">
                    <label for="usuario">Usuário:</label>
                    <input type="text" id="usuario" name="usuario" required>
                </div>
                <div class="form-group">
                    <label for="senha">Senha:</label>
                    <input type="password" id="senha" name="senha" required>
                </div>
                <button type="submit" class="btn btn-primary">Entrar</button>
            </form>
            <div id="mensagem"></div>
        </div>
    </div>

    <script src="script.js"></script>
</body>

</html>