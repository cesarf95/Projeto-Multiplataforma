<?php

$host = "sql.freedb.tech";
$porta = "3306";
$banco = "freedb_ZbTuse3Y";
$usuario = "u_huyrgA";
$senha = "3zQdQ3OXWTk9";

try {

    $pdo = new PDO(
        "mysql:host=$host;port=$porta;dbname=$banco;charset=utf8mb4",
        $usuario,
        $senha
    );

    $pdo->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

} catch (PDOException $e) {

    die("Erro na conexão com o banco: " . $e->getMessage());

}