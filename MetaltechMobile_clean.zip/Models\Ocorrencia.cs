﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetaltechMobile.Models
{
    public class Ocorrencia
    {
        public int Id { get; set; }
        public string Maquina { get; set; }
        public string CodigoErro { get; set; }
        public string DescricaoErro { get; set; }
        public DateTime DataHora { get; set; }
        public string Operador { get; set; }
        public string Status { get; set; }
    }
}
