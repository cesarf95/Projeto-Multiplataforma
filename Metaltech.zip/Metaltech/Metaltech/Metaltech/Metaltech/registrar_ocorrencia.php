<?php

header("Content-Type: application/json; charset=UTF-8");

require_once "conecta.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Método não permitido."
    ]);

    exit;
}

$dados = json_decode(file_get_contents("php://input"), true);

$usuario = $dados["usuario"] ?? "";
$perfil = $dados["perfil"] ?? "";
$maquina = $dados["maquina"] ?? "";
$codigoErro = $dados["codigo_erro"] ?? "";
$descricaoErro = $dados["descricao_erro"] ?? "";
$dataHora = $dados["data_hora"] ?? "";
$status = $dados["status"] ?? "Aberto";

if (
    empty($usuario) ||
    empty($perfil) ||
    empty($maquina) ||
    empty($codigoErro) ||
    empty($descricaoErro) ||
    empty($dataHora)
) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Preencha todos os campos obrigatórios."
    ]);

    exit;
}

try {

    $sql = "INSERT INTO ocorrencias
            (usuario, perfil, maquina, codigo_erro, descricao_erro, data_hora, status)
            VALUES
            (:usuario, :perfil, :maquina, :codigo_erro, :descricao_erro, :data_hora, :status)";

    $stmt = $pdo->prepare($sql);

    $stmt->bindParam(":usuario", $usuario);
    $stmt->bindParam(":perfil", $perfil);
    $stmt->bindParam(":maquina", $maquina);
    $stmt->bindParam(":codigo_erro", $codigoErro);
    $stmt->bindParam(":descricao_erro", $descricaoErro);
    $stmt->bindParam(":data_hora", $dataHora);
    $stmt->bindParam(":status", $status);

    $stmt->execute();

    echo json_encode([
        "sucesso" => true,
        "mensagem" => "Ocorrência registrada com sucesso!"
    ]);

} catch (PDOException $e) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Erro ao registrar ocorrência."
    ]);
}