<?php
session_start();

// Verificar se está logado
if (!isset($_SESSION['usuario']) || !isset($_SESSION['perfil'])) {
    header("Location: index.php");
    exit;
}

$usuario = $_SESSION['usuario'];
$perfil = $_SESSION['perfil'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Ocorrência - MetalTech SIME</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>MetalTech</h1>
            <div class="user-info">
                <span class="perfil-badge perfil-<?php echo strtolower($perfil); ?>">Perfil: <?php echo htmlspecialchars($perfil); ?></span>
                <a href="menu.php" class="btn btn-info" style="margin-left: 20px;">Voltar</a>
            </div>
        </div>

        <div class="card">
            <h2>Registrar Ocorrência</h2>
            <form id="registrarForm">
                <div class="form-group">
                    <label for="operador">Operador:</label>
                    <input type="text" id="operador" name="operador" value="<?php echo htmlspecialchars($usuario); ?>" required>
                </div>

                <div class="form-group">
                    <label for="maquina">Máquina:</label>
                    <input type="text" id="maquina" name="maquina" placeholder="Ex: tcnc01, fcnc01, cpr01" required>
                </div>

                <div class="form-group">
                    <label for="codigo_erro">Código do Erro:</label>
                    <input type="text" id="codigo_erro" name="codigo_erro" placeholder="Ex: ER001" required>
                </div>

                <div class="form-group">
                    <label for="descricao_erro">Descrição do Erro:</label>
                    <textarea id="descricao_erro" name="descricao_erro" placeholder="Descreva a falha ocorrida" required></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Registrar Ocorrência</button>
            </form>
            <div id="mensagem"></div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
