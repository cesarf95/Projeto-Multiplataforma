﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetaltechMobile.Models
{
    public class RespostaOcorrencias
    {
        public bool sucesso { get; set; }
        public List<Ocorrencia> dados { get; set; }
    }
}
