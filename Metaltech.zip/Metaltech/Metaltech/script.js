// Função para mostrar mensagens
function mostrarMensagem(mensagem, tipo = 'sucesso') {
    const divMensagem = document.getElementById('mensagem');
    divMensagem.textContent = mensagem;
    divMensagem.className = tipo === 'sucesso' ? 'mensagem-sucesso' : 'mensagem-erro';
    divMensagem.style.display = 'block';

    setTimeout(() => {
        divMensagem.style.display = 'none';
    }, 2000);
}

// Login
document.getElementById('loginForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();

    const usuario = document.getElementById('usuario').value;
    const senha = document.getElementById('senha').value;

    // Validação estática (igual ao mobile)
    let perfil = null;
    if (usuario === 'operador' && senha === '1234') {
        perfil = 'Operador';
    } else if (usuario === 'supervisor' && senha === 'admin') {
        perfil = 'Supervisor';
    }

    if (perfil) {
        // Salvar na sessão via PHP
        const formData = new FormData();
        formData.append('usuario', usuario);
        formData.append('perfil', perfil);

        try {
            const response = await fetch('login.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.sucesso) {
                mostrarMensagem('Login realizado com sucesso!', 'sucesso');
                setTimeout(() => {
                    window.location.href = 'menu.php';
                }, 3000);
            } else {
                mostrarMensagem('Erro ao fazer login.', 'erro');
            }
        } catch (error) {
            mostrarMensagem('Erro de conexão.', 'erro');
        }
    } else {
        mostrarMensagem('Usuário ou senha incorretos.', 'erro');
    }
});

// Registrar Ocorrência
document.getElementById('registrarForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();

    const dados = {
        usuario: document.getElementById('operador').value,
        perfil: 'Operador',
        maquina: document.getElementById('maquina').value,
        codigo_erro: document.getElementById('codigo_erro').value,
        descricao_erro: document.getElementById('descricao_erro').value,
        data_hora: new Date().toISOString().slice(0, 19).replace('T', ' '),
        status: 'Aberto'
    };

    try {
        const response = await fetch('registrar_ocorrencia.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        });

        const result = await response.json();

        if (result.sucesso) {
            mostrarMensagem('Ocorrência registrada com sucesso!', 'sucesso');

            // Perguntar se deseja inserir outro registro
            if (confirm('Deseja inserir outro registro?')) {
                // Limpar campos
                document.getElementById('maquina').value = '';
                document.getElementById('codigo_erro').value = '';
                document.getElementById('descricao_erro').value = '';
            } else {
                // Voltar para o menu
                window.location.href = 'menu.php';
            }
        } else {
            mostrarMensagem(result.mensagem || 'Erro ao registrar ocorrência.', 'erro');
        }
    } catch (error) {
        mostrarMensagem('Erro de conexão.', 'erro');
    }
});

// Atualizar Status
async function atualizarStatus(id, novoStatus) {
    if (novoStatus === 'Fechado') {
        if (!confirm('Ao marcar como "Fechado", a ocorrência será excluída permanentemente. Deseja continuar?')) {
            return;
        }
    }

    try {
        const response = await fetch('atualizar_status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id: id, status: novoStatus })
        });

        const result = await response.json();

        if (result.sucesso) {
            mostrarMensagem(result.mensagem, 'sucesso');
            // Recarregar a lista imediatamente
            await carregarOcorrencias();
        } else {
            mostrarMensagem(result.mensagem || 'Erro ao atualizar status.', 'erro');
        }
    } catch (error) {
        mostrarMensagem('Erro de conexão.', 'erro');
    }
}

// Excluir Ocorrência
async function excluirOcorrencia(id) {
    if (!confirm('Deseja realmente excluir esta ocorrência?')) {
        return;
    }

    try {
        const response = await fetch('excluir_ocorrencia.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id: id })
        });

        const result = await response.json();

        if (result.sucesso) {
            mostrarMensagem('Ocorrência excluída com sucesso!', 'sucesso');
            // Recarregar a lista imediatamente
            await carregarOcorrencias();
        } else {
            mostrarMensagem(result.mensagem || 'Erro ao excluir ocorrência.', 'erro');
        }
    } catch (error) {
        mostrarMensagem('Erro de conexão.', 'erro');
    }
}

// Carregar Ocorrências
async function carregarOcorrencias() {
    try {
        const response = await fetch('listar_ocorrencias.php');
        const result = await response.json();

        if (result.sucesso && result.dados) {
            const tbody = document.getElementById('listaOcorrencias');
            if (!tbody) {
                return;
            }

            tbody.innerHTML = '';

            if (result.dados.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">Nenhuma ocorrência encontrada</td></tr>';
            } else {
                result.dados.forEach(ocorrencia => {
                    const statusClass = getStatusClass(ocorrencia.status);
                    const dataFormatada = new Date(ocorrencia.data_hora).toLocaleString('pt-BR');

                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${ocorrencia.maquina}</td>
                        <td>${ocorrencia.codigo_erro}</td>
                        <td>${ocorrencia.descricao_erro}</td>
                        <td>${ocorrencia.operador}</td>
                        <td>${dataFormatada}</td>
                        <td><span class="status-badge ${statusClass}">${ocorrencia.status}</span></td>
                        <td class="actions">
                            <button class="btn btn-info" onclick="abrirModalStatus(${ocorrencia.id}, '${ocorrencia.status}')">Editar</button>
                            <button class="btn btn-danger" onclick="excluirOcorrencia(${ocorrencia.id})">Excluir</button>
                        </td>
                    `;
                    tbody.appendChild(row);
                });
            }

            // Atualizar indicador de última atualização
            const ultimaAtualizacao = document.getElementById('ultimaAtualizacao');
            if (ultimaAtualizacao) {
                ultimaAtualizacao.textContent = 'Última atualização: ' + new Date().toLocaleTimeString();
            }
        }
    } catch (error) {
        console.error('Erro ao carregar ocorrências:', error);
    }
}

// Carregar Estatísticas do Dashboard
async function carregarEstatisticas() {
    try {
        const response = await fetch('listar_ocorrencias.php');
        const result = await response.json();

        if (result.sucesso && result.dados) {
            const ocorrencias = result.dados;

            // Filtrar apenas ocorrências do mês atual
            const mesAtual = new Date().getMonth();
            const anoAtual = new Date().getFullYear();
            const ocorrenciasMes = ocorrencias.filter(o => {
                const data = new Date(o.data_hora);
                return data.getMonth() === mesAtual && data.getFullYear() === anoAtual;
            });

            // Total de ocorrências no mês
            document.getElementById('totalMes').textContent = ocorrenciasMes.length;

            // Máquina com mais ocorrências
            if (ocorrenciasMes.length > 0) {
                const maquinaMais = ocorrenciasMes.reduce((acc, curr) => {
                    acc[curr.maquina] = (acc[curr.maquina] || 0) + 1;
                    return acc;
                }, {});

                const maquinaTop = Object.entries(maquinaMais).sort((a, b) => b[1] - a[1])[0];
                document.getElementById('maquinaMais').textContent = `${maquinaTop[0]} (${maquinaTop[1]})`;

                // Média por dia
                const diasNoMes = new Date(anoAtual, mesAtual + 1, 0).getDate();
                const media = (ocorrenciasMes.length / diasNoMes).toFixed(1);
                document.getElementById('mediaDia').textContent = media;

                // Ocorrências por máquina
                const tbody = document.getElementById('listaEstatisticas');
                tbody.innerHTML = '';

                Object.entries(maquinaMais)
                    .sort((a, b) => b[1] - a[1])
                    .forEach(([maquina, count]) => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${maquina}</td>
                            <td>${count}</td>
                        `;
                        tbody.appendChild(row);
                    });
            } else {
                document.getElementById('maquinaMais').textContent = '-';
                document.getElementById('mediaDia').textContent = '0';
                document.getElementById('listaEstatisticas').innerHTML = '<tr><td colspan="2" style="text-align: center;">Nenhum dado disponível</td></tr>';
            }
        }
    } catch (error) {
        console.error('Erro ao carregar estatísticas:', error);
    }
}

// Função auxiliar para classe do status
function getStatusClass(status) {
    switch(status.toLowerCase()) {
        case 'aberto': return 'status-aberto';
        case 'em análise': return 'status-em-analise';
        case 'resolvido': return 'status-resolvido';
        case 'fechado': return 'status-fechado';
        default: return '';
    }
}

// Modal para editar status
function abrirModalStatus(id, statusAtual) {
    const novoStatus = prompt('Selecione o novo status:\n1 - Aberto\n2 - Em Análise\n3 - Resolvido\n4 - Fechado\n\nDigite o número:', '');

    if (novoStatus) {
        const statusMap = {
            '1': 'Aberto',
            '2': 'Em Análise',
            '3': 'Resolvido',
            '4': 'Fechado'
        };

        if (statusMap[novoStatus]) {
            atualizarStatus(id, statusMap[novoStatus]);
        } else {
            mostrarMensagem('Opção inválida.', 'erro');
        }
    }
}

// Carregar dados ao carregar a página
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('listaOcorrencias')) {
        carregarOcorrencias();

        // Atualizar automaticamente a cada 10 segundos
        setInterval(function() {
            carregarOcorrencias();
        }, 5000);
    }

    if (document.getElementById('totalMes')) {
        carregarEstatisticas();
    }
});
