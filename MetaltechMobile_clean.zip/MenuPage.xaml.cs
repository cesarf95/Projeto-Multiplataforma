﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MetaltechMobile
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MenuPage : ContentPage
    {
        private string operador;
        private string perfil;
        public MenuPage(string operador, string perfil)
        {
            InitializeComponent();
            this.operador = operador;
            this.perfil = perfil;

            lblMenu.Text = $"Menu do {perfil}";

            // Esconder opções específicas do Supervisor para Operadores
            if (perfil == "Operador")
            {
                btnConsultar.IsVisible = false;
                btnDashboard.IsVisible = false;
            }
        }

        private async void btnRegistrar_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new OcorrenciaPage(operador));
        }

        private async void btnSair_Clicked(object sender, EventArgs e)
        {
            bool sair = await DisplayAlert(
               "Sair",
               "Deseja realmente sair?",
               "Sim",
               "Não");

            if (sair)
            {
                Application.Current.MainPage =
                    new NavigationPage(new LoginPage());
            }
        }

        private async void btnConsultar_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new OcorrenciasPage(perfil));
        }

        private async void btnDashboard_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new DashboardPage());
        }
    }
}