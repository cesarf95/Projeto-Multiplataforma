<?php
session_start();

// Verificar se está logado
if (!isset($_SESSION['usuario']) || !isset($_SESSION['perfil'])) {
    header("Location: index.php");
    exit;
}

// Apenas Supervisor pode acessar
if ($_SESSION['perfil'] !== 'Supervisor') {
    header("Location: menu.php");
    exit;
}

$usuario = $_SESSION['usuario'];
$perfil = $_SESSION['perfil'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ocorrências - MetalTech SIME</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>MetalTech</h1>
            <div class="user-info">
                <span class="perfil-badge perfil-<?php echo strtolower($perfil); ?>">Perfil: <?php echo htmlspecialchars($perfil); ?></span>
                <a href="menu.php" class="btn btn-info" style="margin-left: 20px;">Voltar</a>
            </div>
        </div>

        <div class="card">
            <h2>Consultar Ocorrências</h2>
            <button class="btn btn-primary" onclick="carregarOcorrencias()" style="margin-bottom: 20px;">Atualizar Lista</button>

            <table class="table">
                <thead>
                    <tr>
                        <th>Máquina</th>
                        <th>Código</th>
                        <th>Descrição</th>
                        <th>Operador</th>
                        <th>Data/Hora</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="listaOcorrencias">
                    <tr>
                        <td colspan="7" style="text-align: center;">Carregando...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="footer-status">
        <span id="ultimaAtualizacao"></span>
    </div>

    <script src="script.js"></script>
</body>
</html>
