<?php

$dados = [
    "usuario" => "operador",
    "perfil" => "Operador",
    "maquina" => "tcnc01",
    "codigo_erro" => "ER001",
    "descricao_erro" => "Falha no motor",
    "data_hora" => date("Y-m-d H:i:s"),
    "status" => "Aberto"
];

$url = "http://localhost:8080/Metaltech/registrar_ocorrencia.php";

$opcoes = [
    "http" => [
        "method" => "POST",
        "header" => "Content-Type: application/json\r\n",
        "content" => json_encode($dados),
        "ignore_errors" => true
    ]
];

$contexto = stream_context_create($opcoes);

$resposta = file_get_contents($url, false, $contexto);

echo $resposta;