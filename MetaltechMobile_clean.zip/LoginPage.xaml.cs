﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MetaltechMobile
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LoginPage : ContentPage
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private async void btnEntrar_Clicked(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text;
            string senha = txtSenha.Text;

            string perfil = null;

            if (usuario == "operador" && senha == "1234")
            {
                perfil = "Operador";
            }
            else if (usuario == "supervisor" && senha == "admin")
            {
                perfil = "Supervisor";
            }

            if (perfil != null)
            {
                await DisplayAlert(
                    "Sucesso",
                    $"Login realizado com sucesso! Perfil: {perfil}",
                    "OK");

                await Navigation.PushAsync(new MenuPage(usuario, perfil));
            }
            else
            {
                await DisplayAlert(
                    "Erro",
                    "Usuário ou senha incorretos.",
                    "OK");
            }
        }
    }
}