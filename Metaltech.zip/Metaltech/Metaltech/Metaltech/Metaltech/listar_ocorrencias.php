<?php

header("Content-Type: application/json; charset=UTF-8");

require_once "conecta.php";

if ($_SERVER["REQUEST_METHOD"] !== "GET") {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Método não permitido."
    ]);

    exit;
}

try {

    $sql = "SELECT id, maquina, codigo_erro, descricao_erro, data_hora, usuario as operador, status
            FROM ocorrencias
            ORDER BY data_hora DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $ocorrencias = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "sucesso" => true,
        "dados" => $ocorrencias
    ]);

} catch (PDOException $e) {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Erro ao listar ocorrências."
    ]);
}
