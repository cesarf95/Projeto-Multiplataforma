using MetaltechMobile.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MetaltechMobile
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DashboardPage : ContentPage
    {
        public DashboardPage()
        {
            InitializeComponent();
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await CarregarEstatisticas();
        }

        private async System.Threading.Tasks.Task CarregarEstatisticas()
        {
            try
            {
                using (HttpClient cliente = new HttpClient())
                {
                    string url = "http://10.0.2.2/Metaltech/Metaltech/listar_ocorrencias.php";

                    string json = await cliente.GetStringAsync(url);

                    RespostaOcorrencias resposta = JsonConvert.DeserializeObject<RespostaOcorrencias>(json);

                    if (resposta != null && resposta.sucesso && resposta.dados != null)
                    {
                        var ocorrencias = resposta.dados;

                        // Debug: mostrar total de ocorrências carregadas
                        System.Diagnostics.Debug.WriteLine($"Total de ocorrências: {ocorrencias.Count}");

                        // Filtrar apenas ocorrências do mês atual
                        var mesAtual = DateTime.Now.Month;
                        var anoAtual = DateTime.Now.Year;
                        var ocorrenciasMes = ocorrencias
                            .Where(o => o.DataHora.Month == mesAtual && o.DataHora.Year == anoAtual)
                            .ToList();

                        // Debug: mostrar ocorrências do mês
                        System.Diagnostics.Debug.WriteLine($"Ocorrências do mês: {ocorrenciasMes.Count}");

                        // Total de ocorrências (todas, não apenas do mês)
                        lblTotalMes.Text = ocorrencias.Count.ToString();

                        // Máquina com mais ocorrências (usando todas as ocorrências)
                        if (ocorrencias.Any())
                        {
                            var maquinaMais = ocorrencias
                                .GroupBy(o => o.Maquina)
                                .OrderByDescending(g => g.Count())
                                .First();

                            lblMaquinaMais.Text = $"{maquinaMais.Key} ({maquinaMais.Count()})";

                            // Média por dia (usando todas as ocorrências, dividido por dias do mês atual)
                            int diasNoMes = DateTime.DaysInMonth(anoAtual, mesAtual);
                            double media = (double)ocorrencias.Count / diasNoMes;
                            lblMediaDia.Text = media.ToString("F1");
                        }
                        else
                        {
                            lblMaquinaMais.Text = "-";
                            lblMediaDia.Text = "0";
                        }

                        // Ocorrências por máquina (usando todas as ocorrências)
                        var estatisticasMaquina = ocorrencias
                            .GroupBy(o => o.Maquina)
                            .Select(g => new EstatisticaMaquina
                            {
                                Maquina = g.Key,
                                Quantidade = g.Count()
                            })
                            .OrderByDescending(e => e.Quantidade)
                            .ToList();

                        listaEstatisticas.ItemsSource = estatisticasMaquina;
                    }
                    else
                    {
                        lblTotalMes.Text = "0";
                        lblMaquinaMais.Text = "-";
                        lblMediaDia.Text = "0";
                        listaEstatisticas.ItemsSource = null;
                    }
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert(
                    "Erro",
                    "Não foi possível carregar as estatísticas.\n\n" + ex.Message,
                    "OK");
            }
        }

        private async void btnAtualizar_Clicked(object sender, EventArgs e)
        {
            await CarregarEstatisticas();
        }
    }

    public class EstatisticaMaquina
    {
        public string Maquina { get; set; }
        public int Quantidade { get; set; }
    }
}
