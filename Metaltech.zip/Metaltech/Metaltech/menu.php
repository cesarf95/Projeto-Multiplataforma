<?php
session_start();

// Verificar se está logado
if (!isset($_SESSION['usuario']) || !isset($_SESSION['perfil'])) {
    header("Location: index.php");
    exit;
}

$usuario = $_SESSION['usuario'];
$perfil = $_SESSION['perfil'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu - MetalTech </title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>MetalTech</h1>
            <div class="user-info">
                <span class="perfil-badge perfil-<?php echo strtolower($perfil); ?>">Perfil: <?php echo htmlspecialchars($perfil); ?></span>
                <a href="logout.php" class="btn btn-danger" style="margin-left: 20px;">Sair</a>
            </div>
        </div>

        <h2>Menu do <?php echo htmlspecialchars($perfil); ?></h2>

        <div class="menu-grid">
            <div class="menu-item" onclick="window.location.href='registrar.php'">
                <h3>📝 Registrar Ocorrência</h3>
                <p>Inserir novas ocorrências de falhas nas máquinas</p>
            </div>

            <?php if ($perfil === 'Supervisor'): ?>
            <div class="menu-item" onclick="window.location.href='ocorrencias.php'">
                <h3>📋 Consultar Ocorrências</h3>
                <p>Visualizar e gerenciar todas as ocorrências</p>
            </div>

            <div class="menu-item" onclick="window.location.href='dashboard.php'">
                <h3>📊 Dashboard de Indicadores</h3>
                <p>Análise estatística e métricas de falhas</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
