<?php
session_start();

header("Content-Type: application/json; charset=UTF-8");

$usuario = $_POST['usuario'] ?? '';
$perfil = $_POST['perfil'] ?? '';

if (empty($usuario) || empty($perfil)) {
    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Dados incompletos."
    ]);
    exit;
}

$_SESSION['usuario'] = $usuario;
$_SESSION['perfil'] = $perfil;

echo json_encode([
    "sucesso" => true,
    "mensagem" => "Login realizado com sucesso."
]);
