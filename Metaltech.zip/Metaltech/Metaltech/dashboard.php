<?php
session_start();

// Verificar se está logado
if (!isset($_SESSION['usuario']) || !isset($_SESSION['perfil'])) {
    header("Location: index.php");
    exit;
}

// Apenas Supervisor pode acessar
if ($_SESSION['perfil'] !== 'Supervisor') {
    header("Location: menu.php");
    exit;
}

$usuario = $_SESSION['usuario'];
$perfil = $_SESSION['perfil'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - MetalTech</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>MetalTech</h1>
            <div class="user-info">
                <span class="perfil-badge perfil-<?php echo strtolower($perfil); ?>">Perfil: <?php echo htmlspecialchars($perfil); ?></span>
                <a href="menu.php" class="btn btn-info" style="margin-left: 20px;">Voltar</a>
            </div>
        </div>
        

        <h2>Dashboard de Indicadores</h2>
        <h3>Estatísticas Mensais de Erros</h3>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total de Ocorrências no Mês</h3>
                <div class="value" id="totalMes">0</div>
            </div>

            <div class="stat-card">
                <h3>Máquina com Mais Ocorrências</h3>
                <div class="value" id="maquinaMais">-</div>
            </div>

            <div class="stat-card">
                <h3>Média de Ocorrências por Dia</h3>
                <div class="value" id="mediaDia">0</div>
            </div>
        </div>

        <div class="card">
            <h2>Ocorrências por Máquina</h2>
            <button class="btn btn-primary" onclick="carregarEstatisticas()" style="margin-bottom: 20px;">Atualizar Dados</button>

            <table class="table">
                <thead>
                    <tr>
                        <th>Máquina</th>
                        <th>Quantidade</th>
                    </tr>
                </thead>
                <tbody id="listaEstatisticas">
                    <tr>
                        <td colspan="2" style="text-align: center;">Carregando...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
