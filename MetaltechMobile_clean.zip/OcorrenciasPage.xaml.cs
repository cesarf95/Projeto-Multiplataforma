﻿using MetaltechMobile.Models;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Net.Http;
using System.Text;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MetaltechMobile
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class OcorrenciasPage : ContentPage
    {
        private string perfil;
        public OcorrenciasPage(string perfil = "Operador")
        {
            InitializeComponent();
            this.perfil = perfil;
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();

            await CarregarOcorrencias();
        }

        private async System.Threading.Tasks.Task CarregarOcorrencias()
        {
            try
            {
                using (HttpClient cliente = new HttpClient())
                {
                    string url =
                        "http://10.0.2.2/Metaltech/Metaltech/listar_ocorrencias.php";

                    string json =
                        await cliente.GetStringAsync(url);

                    RespostaOcorrencias resposta =
                        JsonConvert.DeserializeObject<RespostaOcorrencias>(json);

                    if (resposta != null && resposta.sucesso)
                    {
                        listaOcorrencias.ItemsSource = resposta.dados;
                    }
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert(
                    "Erro",
                    "Não foi possível carregar as ocorrências.\n\n" +
                    ex.Message,
                    "OK");
            }
        }

        private async void btnEditar_Clicked(object sender, EventArgs e)
        {
            var button = sender as Button;
            var ocorrencia = button.CommandParameter as Ocorrencia;

            string novoStatus = await DisplayActionSheet(
                "Selecione o novo status",
                "Cancelar",
                null,
                "Aberto",
                "Em Análise",
                "Resolvido",
                "Fechado");

            if (!string.IsNullOrEmpty(novoStatus) && novoStatus != "Cancelar")
            {
                if (novoStatus == "Fechado")
                {
                    bool confirmar = await DisplayAlert(
                        "Confirmar Exclusão",
                        "Ao marcar como 'Fechado', a ocorrência será excluída permanentemente. Deseja continuar?",
                        "Sim",
                        "Não");

                    if (confirmar)
                    {
                        await ExcluirOcorrencia(ocorrencia);
                    }
                }
                else
                {
                    await AtualizarStatus(ocorrencia, novoStatus);
                }
            }
        }

        private async void btnExcluir_Clicked(object sender, EventArgs e)
        {
            var button = sender as Button;
            var ocorrencia = button.CommandParameter as Ocorrencia;

            bool confirmar = await DisplayAlert(
                "Confirmar Exclusão",
                $"Deseja realmente excluir a ocorrência da máquina {ocorrencia.Maquina}?",
                "Sim",
                "Não");

            if (confirmar)
            {
                await ExcluirOcorrencia(ocorrencia);
            }
        }

        private async System.Threading.Tasks.Task AtualizarStatus(Ocorrencia ocorrencia, string novoStatus)
        {
            try
            {
                using (HttpClient cliente = new HttpClient())
                {
                    string url = "http://10.0.2.2/Metaltech/Metaltech/atualizar_status.php";

                    var dados = new
                    {
                        id = ocorrencia.Id,
                        status = novoStatus
                    };

                    string json = JsonConvert.SerializeObject(dados);
                    StringContent conteudo = new StringContent(json, Encoding.UTF8, "application/json");

                    HttpResponseMessage resposta = await cliente.PostAsync(url, conteudo);
                    string resultado = await resposta.Content.ReadAsStringAsync();

                    if (resposta.IsSuccessStatusCode)
                    {
                        await DisplayAlert("Sucesso", "Status atualizado com sucesso!", "OK");
                    }
                    else
                    {
                        await DisplayAlert("Erro", $"Não foi possível atualizar o status.\n{resultado}", "OK");
                    }

                    await CarregarOcorrencias();
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Erro", ex.Message, "OK");
            }
        }

        private async System.Threading.Tasks.Task ExcluirOcorrencia(Ocorrencia ocorrencia)
        {
            try
            {
                using (HttpClient cliente = new HttpClient())
                {
                    string url = "http://10.0.2.2/Metaltech/Metaltech/excluir_ocorrencia.php";

                    var dados = new
                    {
                        id = ocorrencia.Id
                    };

                    string json = JsonConvert.SerializeObject(dados);
                    StringContent conteudo = new StringContent(json, Encoding.UTF8, "application/json");

                    HttpResponseMessage resposta = await cliente.PostAsync(url, conteudo);
                    string resultado = await resposta.Content.ReadAsStringAsync();

                    if (resposta.IsSuccessStatusCode)
                    {
                        await DisplayAlert("Sucesso", "Ocorrência excluída com sucesso!", "OK");
                    }
                    else
                    {
                        await DisplayAlert("Erro", $"Não foi possível excluir a ocorrência.\n{resultado}", "OK");
                    }

                    await CarregarOcorrencias();
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Erro", ex.Message, "OK");
            }
        }
    }
}